package com.pet.PetPeers.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="PET")
public class Pet {

	@Id
	@Column(name="PETID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long petId;
	@Column(name="PETNAME")
	private String petName;
	@Column(name="PETAGE")
	private Integer petAge;
	@Column(name="PETPLACE")
	private String petPlace;
	@Column(name="PETOWNERID")
	private Long petOwnerId;

	public long getPetId() {
		return petId;
	}

	public void setPetId(long petId) {
		this.petId = petId;
	}

	public String getPetName() {
		return petName;
	}

	public void setPetName(String petName) {
		this.petName = petName;
	}

	public Integer getPetAge() {
		return petAge;
	}

	public void setPetAge(Integer petAge) {
		this.petAge = petAge;
	}

	public String getPetPlace() {
		return petPlace;
	}

	public void setPetPlace(String petPlace) {
		this.petPlace = petPlace;
	}

	public Long getPetOwnerId() {
		return petOwnerId;
	}

	public void setPetOwnerId(Long petOwnerId) {
		this.petOwnerId = petOwnerId;
	}


}