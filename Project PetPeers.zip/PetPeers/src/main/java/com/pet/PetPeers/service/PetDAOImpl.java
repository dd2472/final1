package com.pet.PetPeers.service;

import java.util.List;

import com.pet.PetPeers.dao.PetDAO;
import com.pet.PetPeers.model.Pet;

public class PetDAOImpl implements PetDAO {

	@Override
	public List<Pet> getAllPets() {
// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Pet> getMyPets(int integer) {
// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Pet savePet(Pet pet) {
// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Pet buyPet(int a, int b) {
// TODO Auto-generated method stub
		return null;
	}

}
