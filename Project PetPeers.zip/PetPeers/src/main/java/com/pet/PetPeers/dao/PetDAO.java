package com.pet.PetPeers.dao;

import java.util.List;

import com.pet.PetPeers.model.Pet;

public interface PetDAO {
	public abstract List<Pet> getAllPets();

	public abstract List<Pet> getMyPets(int integer);

	public abstract Pet savePet(Pet pet);

	public abstract Pet buyPet(int a, int b);

}