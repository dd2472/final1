
package com.pet.PetPeers.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class UserRegistrataionController {

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String userRegistration() {

		return "registrationPage";

	}

}
