package com.pet.PetPeers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@SpringBootApplication
@Controller
public class PetPeersApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetPeersApplication.class, args);
	}

	
	  @GetMapping("/registrationPage") 
	  public String registrationPage() {
		  
		  return "registrationPage"; }
	  
	 @GetMapping("/loginPage")
	 public ModelAndView response
	 (@RequestParam("Name")
	  String Name, @RequestParam("password")
	 String password) {
	  
	  System.out.println(Name); 
	  System.out.println(password);
	  
	  System.out.println("UserLogincontroller");
	  ModelAndView mv = new
	  ModelAndView(); 
	  mv.addObject("Name", Name);
	  mv.setViewName("loginPage");
	  return mv; 
	  }
	 
}
