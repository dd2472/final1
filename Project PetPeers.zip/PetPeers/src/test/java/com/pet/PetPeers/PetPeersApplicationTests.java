package com.pet.PetPeers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetPeersApplicationTests {

	@Test
	void contextLoads() {
	}

}
